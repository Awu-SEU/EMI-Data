# -*- coding: utf-8 -*-


# Extract information from the original data

import os
import pandas as pd
import numpy as np


# 1. Read subfolder
parent_directory = 'E:/2024/科研/PZT测试数据/无线铜壳'
data = []

# Traverse the subfolders under the folder
for subfolder_name in os.listdir(parent_directory):
    subfolder_path = os.path.join(parent_directory, subfolder_name)
    
    if os.path.isdir(subfolder_path): 
        file_list = os.listdir(subfolder_path)
        
        for file_name in file_list:
            file_path = os.path.join(subfolder_path, file_name)
            
            if os.path.isfile(file_path):
                df = pd.read_csv(file_path, delimiter=',', header=0) 
                Temperature = df.iloc[2, 4] 
                Peak = df.iloc[:, 2].max()  
                Frequency = df.iloc[:, 1][df.iloc[:, 2].idxmax()]

                # The trapz function is used to calculate the area of the data in the corresponding interval
                area1 = np.trapz(df.iloc[0:43, 2].values)
                area2 = np.trapz(df.iloc[43:86, 2].values)
                area3 = np.trapz(df.iloc[86:128, 2].values)
                area4 = np.trapz(df.iloc[128:171, 2].values)
                area5 = np.trapz(df.iloc[171:213, 2].values)
                area6 = np.trapz(df.iloc[213:256, 2].values)
                area7 = np.trapz(df.iloc[256:299, 2].values)
                area8 = np.trapz(df.iloc[299:341, 2].values)
                area9 = np.trapz(df.iloc[341:384, 2].values)
                area10 = np.trapz(df.iloc[384:426, 2].values)
                area11 = np.trapz(df.iloc[426:469, 2].values)
                area12 = np.trapz(df.iloc[469:512, 2].values)
                
                Load = int(subfolder_name[:3])  # Use the subfolder name as the load label
                
                # Add data to the list
                data.append([Temperature, Peak, Frequency, area1, area2, area3, 
                             area4, area5, area6, area7, area8, area9, area10, 
                             area11, area12, Load])

# 2. Create a DataFrame
df = pd.DataFrame(data, columns=['Temperature', 'Peak', 'Frequency', 'Area1', 
                                 'Area2', 'Area3', 'Area4', 'Area5', 'Area6', 
                                 'Area7', 'Area8', 'Area9', 'Area10', 'Area11', 
                                 'Area12', 'Load'])
#print(df)
